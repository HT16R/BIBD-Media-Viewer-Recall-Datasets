                                                                                                             Datasets


- This deposit contains two Excel workbooks accompanying Chapter 4 (Research Designs) of a forthcoming academic book on Quantitative Media Research with a focus on the Global South, but with equivalent Global application.
- The files illustrate a 3 × 3 Balanced Incomplete Block Design (BIBD) for viewer recall of nine fictional branded products (T1–T9) across 12 episodes of a streaming series, grouped by category for strict pair-wise balance.

A) Dataset Overview:

   • This repository contains two datasets related to a Balanced Incomplete Block Design (BIBD Experimental Design) used for evaluating viewer recall of branded products in a web series.
   • The datasets complement example 38) in the textbook focusing on basic statistical methods for media research education, illustrating key concepts in experimental design; 
     specifically BIBD and its applications in understanding media exposure.
   

B) Datasets:

   • BIBD_Viewer_Recall_Score.xlsx
   • BIBD_50_Random_Viewer_Recall_Scores.xlsx

   - Both datasets follow the BIBD design principles to ensure balanced exposure to treatments (branded products) across episodes, with controlled replications to account for viewer demographic variation.

-> Important Note on Replications and Sample Size:

   • The underlying BIBD structure is fixed: 12 episodes × 3 brands each = 36 treatment occurrences (block-treatment combination).
   • One complete replication = one independent run of the entire design on a fresh group of respondents.
   • Each replication uses 6 unique respondents (30 total across 5 replications), with some viewing multiple episodes; yielding 216 observations per replication (⸪12 episodes × 6 respondents × 3 brands).
   • The file 'BIBD_Viewer_Recall_Score.xlsx' contains only the viewer recall scores of 360 rows/observations across the 9 brands. 
   • The file 'BIBD_50_Random_Viewer_Recall_Scores.xlsx'extracts the first two replications, and retains only 50 randomly chosen rows for compactness, 
     while explicitly labelling the demographic stratum (R1, R2). 
   • Note that the first two replications have a total of 432 rows/observations, while the full five replications have a total of 1080 rows/observations.


C) File contents – Definitive Description:

1. BIBD_Viewer_Recall_Score.xlsx
   
   • 360 rows extracted from the full 5-replication dataset (1,080 total observations).                        
   • Each replication uses the identical block layout but fresh, randomly simulated recall scores.  
   • No Replication or Respondent column — this file focuses on pure design balance and variation.

2. BIBD_50_Random_Viewer_Recall_Scores.xlsx
 
   • 50 randomly selected rows from the first two replications (432 observations total for R1+R2).
   • Additional columns (Replication, Respondent, Row_ID) are added solely to illustrate demographic stratification in practice.  
   • In real studies, each replication would correspond to a distinct viewer segment (age/gender/media consumption habits, etc.).

D) Licensing: 

   • This repository is licensed under MIT, equivalent to CC BY 4.0 for data reuse — attribute as per LICENSE.
