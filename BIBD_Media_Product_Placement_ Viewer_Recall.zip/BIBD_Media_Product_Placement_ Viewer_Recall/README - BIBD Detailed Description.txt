                                                                                   BIBD - Viewer Recall Score Datasets

A) Dataset Description:

1. BIBD Viewer Recall Score.xlsx (360 Rows)

-> Description: 

  • Contains 360 randomly selected observations extracted from the full 5-replication dataset (1,080 total observations: 12 episodes × 6 viewers × 3 brands × 5 replications). 
    Each episode features 3 branded products, with a total of 9 fictional brands (products) in the study. 
  • The recall scores represent how well viewers remember the products featured in the episodes.

-> Columns:

  • Respondent_ID: A unique identifier for each respondent.
  • Blocks (Episodes): The episode in which the product appeared (Episode 1 to Episode 12).
  • Treatments (Branded Products): The branded product (T1 to T9) featured in each episode.
  • Viewer Recall Score: The recall score (1-10) indicating how well the viewer remembers the product.

2. BIBD_50_Random_Viewer_Recall_Scores.xlsx (50 Rows) 

-> Description: 

  • A variation of the first dataset, this includes an additional *Replication* column to account for different demographic groups of viewers.
  • Each replication consists of a group of respondents with varying demographic characteristics (e.g., gender, age, media consumption habits, etc.)
  • This file is a subset comprising randomly selected rows representing two full replications (R1+R2; 432 rows/observations); 
    with multiple respondents per replication to reflect demographic variation. However, only 50 randomly selected rows are retained here for teaching brevity and quick classroom illustration.
  • Additional column: Replication (R1, R2).

-> Columns:

  • Respondent_ID: A unique identifier for each respondent.
  • Blocks (Episodes): The episode number (1 to 12).
  • Treatments (Branded Products): The branded product (T1 to T9).
  • Viewer Recall Score: The recall score (1-10).
  • Row_ID: A unique row identifier.
  • Replication: The replication group, representing different respondent demographics or the demographic stratum (R1, R2).

Note: *Individual* respondent labels within each replication (e.g., R1_01, R1_02 …) are intentionally omitted for simplicity. 
      In an actual study, each replication would contain its own distinct set of respondents drawn from a different demographic segment.

-> Design Structure:

  • t (number of treatments): 9 (T1 to T9).
  • b (number of blocks): 12 episodes.
  • k (block size): 3 treatments per block (episode).
  • r (repetition per treatment): Each treatment appears 4 times.
  • λ (pairwise repetition): Each pair of treatments appears exactly once.

  These datasets follow the BIBD parameters to ensure each product is tested fairly across all episodes, without any product being overexposed or underexposed.

-> Data Simulation:

  • The Balanced Incomplete Block Design structure (v=9, b=12, r=4, k=3, λ=1) was manually constructed to ensure every pair of the nine branded products appears together in exactly one episode (full layout shown in Chapter 4/Tables 25 – 25.5 of the accompanying textbook). 
  • Viewer recall scores (1–10 Graphic Rating Scale) were then simulated in R around this fixed design using uniform random draws, scaled, and replicated across respondent groups for illustrative and educational purposes.
  • Viewer recall scores measure how well a product was remembered by the viewer after watching a given episode of a web series.


B) Design and Statistical Considerations:

-> Balanced Incomplete Block Design (BIBD):

  • In this design, 9 treatments (products) are spread across 12 episodes (blocks). Each episode contains exactly 3 treatments, and every treatment appears 4 times across the episodes.
  • The design ensures that each pair of products (treatment pairs) appears together exactly once (λ = 1), providing a balanced comparison of the treatments.
  • Replications: Different viewer groups (replications) are used to account for variability across demographic characteristics, providing a more accurate view of how different segments of the audience remember the products.

-> Viewer Recall Scores:

  • Each viewer rates their recall of a product placement on a graphic rating scale (GRS) from 1 to 10.
  • This data can be used to analyse how well different branded products perform in terms of recall, and how viewer demographics (age, media consumption habits, etc.) might affect branded product recall.

C) How to Use This Dataset:

  • These datasets are intended for educational use. They can help students and researchers understand the structure of a Balanced Incomplete Block Design and how the data can be organized for an experimental study.
  • The datasets are also useful for understanding replications and how demographic variation affects outcomes.

D) Limitations:

-> Simulated Data: 

  • The datasets are hypothetical and have been generated for educational purposes.
  • They do not represent real-world viewer data and should be used for understanding the basic principles of a BIBD design.(Real commercial product placement data are proprietary).
  • No Analysis Included: This dataset is intended for instructional purposes. No statistical analyses (e.g., ANOVA or regression) are provided with the dataset, as the goal is to introduce basic concepts and models.

E) Licensing

  • This repository is licensed under MIT, equivalent to CC BY 4.0 for data reuseShare. Reuse, adapt, build upon, but attribute as per LICENSE.
